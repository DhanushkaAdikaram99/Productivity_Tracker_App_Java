/**
 * 
 */
/**
 * 
 */
module ProductivityApp {
	requires java.desktop;
	requires java.sql;
	 

}